import React, { useEffect } from "react";
import { tblHeaderBrands, tblOptionsStaffPage } from "../../ui-config/table";
import { useDispatch, useSelector } from "react-redux";
import {
  checkSingle,
  checkAll,
  setCurrentView,
} from "../../redux/slices/StaffView";
import { getHandler } from "../../utils/handlerReqRes";
import { useLocation } from "react-router-dom";
import { ENTITIES } from "../../ui-config/entities";
import Input from "../common-ui/Input";

export default function StaffTbl() {
  //
  const location = useLocation();
  const dispatch = useDispatch();
  const staff = useSelector((state) => state.staffView.staff);
  const allChecked = useSelector((state) => state.staffView.allChecked);
  //
  useEffect(() => {
    const fetch = async () => {
      const data = await getHandler("/staff");
      dispatch(setCurrentView({ view: ENTITIES.member, data: data.data.staff }));
    };
    fetch();
    // 
    localStorage.setItem('activeTab', ENTITIES.member);
    localStorage.setItem('lastRoute', location.pathname);
  }, []);
  //
  return (
    <div className="w-full border border-neutral-200 rounded-xl overflow-hidden shadow-sm bg-white">
      <table className="w-full ">
        <thead>
          <tr className="tr_thead">
            <th className="th">
              <Input
                type="checkbox"
                checked={allChecked}
                onChange={(e) => dispatch(checkAll())}
              />
            </th>
            {tblHeaderBrands.map((itm, ind) => {
              return (
                <th key={ind} className="th">
                  {itm}
                </th>
              );
            })}
          </tr>
        </thead>

        <tbody>
          {staff && staff?.map((item, ind) => {
            return (
              <tr key={item._id} className="tr_tbody">
                <td className="td">
                  <Input
                    type="checkbox"
                    checked={item.checked}
                    onChange={(e) => dispatch(checkSingle())}
                  />
                </td>
                {/* below padding may apply to all */}
                <td className="py-1.125">{ind}</td>
                <td className="py-1.125">{"item.name"}</td>
                <td className="py-1.125">{"item.generic"}</td>
                <td className="py-1.125">{"item.group"}</td>
                <td className="py-1.125">{"item.mfr"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
